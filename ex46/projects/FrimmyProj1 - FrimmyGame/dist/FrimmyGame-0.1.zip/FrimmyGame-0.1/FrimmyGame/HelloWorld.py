def hello():
	a = raw_input("Enter your name")
	print "Hello world, welcome ",a

