# from sys import argv

script, first, second, third = "FrimmyGame", "can", "haz", "cheezburger"

print "The script is called", script
print "You ", first, second, third
print "Thanks for playing!"